import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import axios from "axios";
import { z } from "zod";
import {
  insertUserSchema,
  insertMedicationSchema,
  insertMedicationScheduleSchema,
  insertMedicationTrackingSchema,
  insertHealthMetricsSchema,
  insertDietRecommendationsSchema
} from "@shared/schema";

const BMI_SERVICE_URL = process.env.BMI_SERVICE_URL || "http://localhost:8000";

export async function registerRoutes(app: Express): Promise<Server> {
  // API Routes
  const apiRouter = app.route("/api");

  // User routes
  app.post("/api/users/register", async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByUsername(userData.username);
      
      if (existingUser) {
        return res.status(409).json({ message: "Username already exists" });
      }
      
      const user = await storage.createUser(userData);
      return res.status(201).json({ 
        id: user.id, 
        username: user.username,
        fullName: user.fullName,
        email: user.email
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/users/login", async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      return res.status(200).json({ 
        id: user.id, 
        username: user.username,
        fullName: user.fullName,
        email: user.email
      });
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Medication routes
  app.get("/api/medications/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const medications = await storage.getMedicationsByUserId(userId);
      return res.status(200).json(medications);
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/medications", async (req: Request, res: Response) => {
    try {
      const medicationData = insertMedicationSchema.parse(req.body);
      const medication = await storage.createMedication(medicationData);
      return res.status(201).json(medication);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.put("/api/medications/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid medication ID" });
      }
      
      const medicationData = insertMedicationSchema.partial().parse(req.body);
      const medication = await storage.updateMedication(id, medicationData);
      
      if (!medication) {
        return res.status(404).json({ message: "Medication not found" });
      }
      
      return res.status(200).json(medication);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.delete("/api/medications/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid medication ID" });
      }
      
      const success = await storage.deleteMedication(id);
      
      if (!success) {
        return res.status(404).json({ message: "Medication not found" });
      }
      
      return res.status(204).send();
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Medication Schedule routes
  app.get("/api/medication-schedules/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const schedules = await storage.getMedicationSchedulesByUserId(userId);
      return res.status(200).json(schedules);
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/medication-schedules", async (req: Request, res: Response) => {
    try {
      const scheduleData = insertMedicationScheduleSchema.parse(req.body);
      const schedule = await storage.createMedicationSchedule(scheduleData);
      return res.status(201).json(schedule);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.put("/api/medication-schedules/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid schedule ID" });
      }
      
      const scheduleData = insertMedicationScheduleSchema.partial().parse(req.body);
      const schedule = await storage.updateMedicationSchedule(id, scheduleData);
      
      if (!schedule) {
        return res.status(404).json({ message: "Schedule not found" });
      }
      
      return res.status(200).json(schedule);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.delete("/api/medication-schedules/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid schedule ID" });
      }
      
      const success = await storage.deleteMedicationSchedule(id);
      
      if (!success) {
        return res.status(404).json({ message: "Schedule not found" });
      }
      
      return res.status(204).send();
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Medication Tracking routes
  app.get("/api/medication-tracking/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const tracking = await storage.getMedicationTrackingByUserId(userId);
      return res.status(200).json(tracking);
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/medication-tracking", async (req: Request, res: Response) => {
    try {
      const trackingData = insertMedicationTrackingSchema.parse(req.body);
      const tracking = await storage.createMedicationTracking(trackingData);
      return res.status(201).json(tracking);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Health Metrics routes
  app.get("/api/health-metrics/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const metrics = await storage.getHealthMetricsByUserId(userId);
      return res.status(200).json(metrics);
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/health-metrics/:userId/latest", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const metric = await storage.getLatestHealthMetric(userId);
      
      if (!metric) {
        return res.status(404).json({ message: "No health metrics found for this user" });
      }
      
      return res.status(200).json(metric);
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/health-metrics", async (req: Request, res: Response) => {
    try {
      const metricData = insertHealthMetricsSchema.parse(req.body);
      const metric = await storage.createHealthMetric(metricData);
      return res.status(201).json(metric);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Diet Recommendations routes
  app.get("/api/diet-recommendations/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const recommendations = await storage.getDietRecommendationsByUserId(userId);
      return res.status(200).json(recommendations);
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/diet-recommendations/:userId/latest", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const recommendation = await storage.getLatestDietRecommendation(userId);
      
      if (!recommendation) {
        return res.status(404).json({ message: "No diet recommendations found for this user" });
      }
      
      return res.status(200).json(recommendation);
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/diet-recommendations", async (req: Request, res: Response) => {
    try {
      const recommendationData = insertDietRecommendationsSchema.parse(req.body);
      const recommendation = await storage.createDietRecommendation(recommendationData);
      return res.status(201).json(recommendation);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      return res.status(500).json({ message: "Server error" });
    }
  });

  // BMI Calculator (proxy to Flask microservice)
  app.post("/api/calculate-bmi", async (req: Request, res: Response) => {
    try {
      const response = await axios.post(`${BMI_SERVICE_URL}/calculate-bmi`, req.body);
      return res.status(200).json(response.data);
    } catch (error) {
      if (axios.isAxiosError(error) && error.response) {
        return res.status(error.response.status).json(error.response.data);
      }
      return res.status(500).json({ message: "Failed to calculate BMI" });
    }
  });

  app.post("/api/bmi-recommendations", async (req: Request, res: Response) => {
    try {
      const response = await axios.post(`${BMI_SERVICE_URL}/bmi-recommendations`, req.body);
      return res.status(200).json(response.data);
    } catch (error) {
      if (axios.isAxiosError(error) && error.response) {
        return res.status(error.response.status).json(error.response.data);
      }
      return res.status(500).json({ message: "Failed to get BMI recommendations" });
    }
  });

  // Server health check
  app.get("/api/health", async (_req: Request, res: Response) => {
    try {
      // Check BMI service health
      const bmiServiceHealth = await axios.get(`${BMI_SERVICE_URL}/health`)
        .then(() => true)
        .catch(() => false);
      
      return res.status(200).json({
        status: "healthy",
        bmiService: bmiServiceHealth ? "connected" : "disconnected"
      });
    } catch (error) {
      return res.status(500).json({ message: "Health check failed" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
