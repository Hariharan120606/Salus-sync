import {
  User, InsertUser, users,
  Medication, InsertMedication, medications,
  MedicationSchedule, InsertMedicationSchedule, medicationSchedules,
  MedicationTracking, InsertMedicationTracking, medicationTracking,
  HealthMetric, InsertHealthMetric, healthMetrics,
  DietRecommendation, InsertDietRecommendation, dietRecommendations
} from "@shared/schema";

// Storage interface
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Medication methods
  getMedicationsByUserId(userId: number): Promise<Medication[]>;
  getMedication(id: number): Promise<Medication | undefined>;
  createMedication(medication: InsertMedication): Promise<Medication>;
  updateMedication(id: number, medication: Partial<InsertMedication>): Promise<Medication | undefined>;
  deleteMedication(id: number): Promise<boolean>;

  // Medication Schedule methods
  getMedicationSchedulesByUserId(userId: number): Promise<MedicationSchedule[]>;
  getMedicationSchedulesByMedicationId(medicationId: number): Promise<MedicationSchedule[]>;
  getMedicationSchedule(id: number): Promise<MedicationSchedule | undefined>;
  createMedicationSchedule(schedule: InsertMedicationSchedule): Promise<MedicationSchedule>;
  updateMedicationSchedule(id: number, schedule: Partial<InsertMedicationSchedule>): Promise<MedicationSchedule | undefined>;
  deleteMedicationSchedule(id: number): Promise<boolean>;

  // Medication Tracking methods
  getMedicationTrackingByUserId(userId: number): Promise<MedicationTracking[]>;
  getMedicationTrackingByScheduleId(scheduleId: number): Promise<MedicationTracking[]>;
  createMedicationTracking(tracking: InsertMedicationTracking): Promise<MedicationTracking>;

  // Health Metrics methods
  getHealthMetricsByUserId(userId: number): Promise<HealthMetric[]>;
  getLatestHealthMetric(userId: number): Promise<HealthMetric | undefined>;
  createHealthMetric(metric: InsertHealthMetric): Promise<HealthMetric>;

  // Diet Recommendations methods
  getDietRecommendationsByUserId(userId: number): Promise<DietRecommendation[]>;
  getLatestDietRecommendation(userId: number): Promise<DietRecommendation | undefined>;
  createDietRecommendation(recommendation: InsertDietRecommendation): Promise<DietRecommendation>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private medications: Map<number, Medication>;
  private medicationSchedules: Map<number, MedicationSchedule>;
  private medicationTrackings: Map<number, MedicationTracking>;
  private healthMetrics: Map<number, HealthMetric>;
  private dietRecommendations: Map<number, DietRecommendation>;
  
  private userId: number;
  private medicationId: number;
  private medicationScheduleId: number;
  private medicationTrackingId: number;
  private healthMetricId: number;
  private dietRecommendationId: number;

  constructor() {
    this.users = new Map();
    this.medications = new Map();
    this.medicationSchedules = new Map();
    this.medicationTrackings = new Map();
    this.healthMetrics = new Map();
    this.dietRecommendations = new Map();
    
    this.userId = 1;
    this.medicationId = 1;
    this.medicationScheduleId = 1;
    this.medicationTrackingId = 1;
    this.healthMetricId = 1;
    this.dietRecommendationId = 1;
    
    // Add demo user
    this.createUser({
      username: "demo",
      password: "password123",
      fullName: "John Doe",
      email: "john.doe@example.com"
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id, createdAt: new Date() };
    this.users.set(id, user);
    return user;
  }

  // Medication methods
  async getMedicationsByUserId(userId: number): Promise<Medication[]> {
    return Array.from(this.medications.values()).filter(
      (medication) => medication.userId === userId
    );
  }

  async getMedication(id: number): Promise<Medication | undefined> {
    return this.medications.get(id);
  }

  async createMedication(insertMedication: InsertMedication): Promise<Medication> {
    const id = this.medicationId++;
    const medication: Medication = { ...insertMedication, id, createdAt: new Date() };
    this.medications.set(id, medication);
    return medication;
  }

  async updateMedication(id: number, medicationUpdate: Partial<InsertMedication>): Promise<Medication | undefined> {
    const medication = this.medications.get(id);
    if (!medication) return undefined;

    const updatedMedication = { ...medication, ...medicationUpdate };
    this.medications.set(id, updatedMedication);
    return updatedMedication;
  }

  async deleteMedication(id: number): Promise<boolean> {
    return this.medications.delete(id);
  }

  // Medication Schedule methods
  async getMedicationSchedulesByUserId(userId: number): Promise<MedicationSchedule[]> {
    return Array.from(this.medicationSchedules.values()).filter(
      (schedule) => schedule.userId === userId
    );
  }

  async getMedicationSchedulesByMedicationId(medicationId: number): Promise<MedicationSchedule[]> {
    return Array.from(this.medicationSchedules.values()).filter(
      (schedule) => schedule.medicationId === medicationId
    );
  }

  async getMedicationSchedule(id: number): Promise<MedicationSchedule | undefined> {
    return this.medicationSchedules.get(id);
  }

  async createMedicationSchedule(insertSchedule: InsertMedicationSchedule): Promise<MedicationSchedule> {
    const id = this.medicationScheduleId++;
    const schedule: MedicationSchedule = { ...insertSchedule, id, createdAt: new Date() };
    this.medicationSchedules.set(id, schedule);
    return schedule;
  }

  async updateMedicationSchedule(id: number, scheduleUpdate: Partial<InsertMedicationSchedule>): Promise<MedicationSchedule | undefined> {
    const schedule = this.medicationSchedules.get(id);
    if (!schedule) return undefined;

    const updatedSchedule = { ...schedule, ...scheduleUpdate };
    this.medicationSchedules.set(id, updatedSchedule);
    return updatedSchedule;
  }

  async deleteMedicationSchedule(id: number): Promise<boolean> {
    return this.medicationSchedules.delete(id);
  }

  // Medication Tracking methods
  async getMedicationTrackingByUserId(userId: number): Promise<MedicationTracking[]> {
    return Array.from(this.medicationTrackings.values()).filter(
      (tracking) => tracking.userId === userId
    );
  }

  async getMedicationTrackingByScheduleId(scheduleId: number): Promise<MedicationTracking[]> {
    return Array.from(this.medicationTrackings.values()).filter(
      (tracking) => tracking.scheduleId === scheduleId
    );
  }

  async createMedicationTracking(insertTracking: InsertMedicationTracking): Promise<MedicationTracking> {
    const id = this.medicationTrackingId++;
    const tracking: MedicationTracking = { ...insertTracking, id, createdAt: new Date() };
    this.medicationTrackings.set(id, tracking);
    return tracking;
  }

  // Health Metrics methods
  async getHealthMetricsByUserId(userId: number): Promise<HealthMetric[]> {
    return Array.from(this.healthMetrics.values())
      .filter((metric) => metric.userId === userId)
      .sort((a, b) => b.measuredAt.getTime() - a.measuredAt.getTime());
  }

  async getLatestHealthMetric(userId: number): Promise<HealthMetric | undefined> {
    const metrics = await this.getHealthMetricsByUserId(userId);
    return metrics.length > 0 ? metrics[0] : undefined;
  }

  async createHealthMetric(insertMetric: InsertHealthMetric): Promise<HealthMetric> {
    const id = this.healthMetricId++;
    const metric: HealthMetric = { ...insertMetric, id, createdAt: new Date() };
    this.healthMetrics.set(id, metric);
    return metric;
  }

  // Diet Recommendations methods
  async getDietRecommendationsByUserId(userId: number): Promise<DietRecommendation[]> {
    return Array.from(this.dietRecommendations.values())
      .filter((recommendation) => recommendation.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getLatestDietRecommendation(userId: number): Promise<DietRecommendation | undefined> {
    const recommendations = await this.getDietRecommendationsByUserId(userId);
    return recommendations.length > 0 ? recommendations[0] : undefined;
  }

  async createDietRecommendation(insertRecommendation: InsertDietRecommendation): Promise<DietRecommendation> {
    const id = this.dietRecommendationId++;
    const recommendation: DietRecommendation = { ...insertRecommendation, id, createdAt: new Date() };
    this.dietRecommendations.set(id, recommendation);
    return recommendation;
  }
}

export const storage = new MemStorage();
