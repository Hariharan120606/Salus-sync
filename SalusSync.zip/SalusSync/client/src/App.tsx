import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import Medications from "@/pages/Medications";
import HealthMetrics from "@/pages/HealthMetrics";
import Calendar from "@/pages/Calendar";
import Settings from "@/pages/Settings";
import Header from "@/components/Header";
import NavigationTabs from "@/components/NavigationTabs";
import Footer from "@/components/Footer";
import Notifications from "@/components/Notifications";
import { useState, createContext, useContext } from "react";
import { User } from "@/lib/types";

// Create auth context to manage user login state
interface AuthContextType {
  user: User | null;
  login: (user: User) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  login: () => {},
  logout: () => {},
});

export const useAuth = () => useContext(AuthContext);

// Demo user for initial login
const demoUser: User = {
  id: 1,
  username: "demo",
  fullName: "John Doe",
  email: "john.doe@example.com",
};

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/medications" component={Medications} />
      <Route path="/health-metrics" component={HealthMetrics} />
      <Route path="/calendar" component={Calendar} />
      <Route path="/settings" component={Settings} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [user, setUser] = useState<User | null>(demoUser); // Auto-login demo user for simplicity

  const login = (loggedInUser: User) => {
    setUser(loggedInUser);
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      <div className="flex flex-col min-h-screen">
        <Header />
        <NavigationTabs />
        <main className="flex-grow container mx-auto p-4 md:p-6">
          <Router />
        </main>
        <Footer />
      </div>
      <Notifications />
      <Toaster />
    </AuthContext.Provider>
  );
}

export default App;
