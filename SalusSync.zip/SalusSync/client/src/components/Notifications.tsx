import { useState, useEffect } from "react";
import { NotificationProps } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

// Example notification for demo purposes
const demoNotification: NotificationProps = {
  id: "med-reminder-1",
  title: "Medication Reminder",
  message: "Time to take Atorvastatin (10mg).",
  type: "medication",
  actions: {
    primary: {
      label: "Take Now",
      onClick: () => console.log("Medication taken"),
    },
    secondary: {
      label: "Dismiss",
      onClick: () => console.log("Notification dismissed"),
    },
  },
};

export default function Notifications() {
  const [notifications, setNotifications] = useState<NotificationProps[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    // Simulate a notification appearing after the component mounts
    const timer = setTimeout(() => {
      setNotifications([demoNotification]);
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  const dismissNotification = (id: string) => {
    setNotifications((prev) => prev.filter((notification) => notification.id !== id));
  };

  const handleTakeNow = (id: string) => {
    // Handle the medication taken action
    toast({
      title: "Medication taken",
      description: "Your medication has been marked as taken.",
    });
    dismissNotification(id);
  };

  if (notifications.length === 0) {
    return null;
  }

  return (
    <div className="fixed bottom-4 right-4 z-50 max-w-sm">
      {notifications.map((notification) => (
        <div
          key={notification.id}
          className="bg-white rounded-lg shadow-lg p-4 mb-3 flex items-start gap-3 border-l-4 border-primary animate-in fade-in slide-in-from-bottom-5"
        >
          <span className="material-icons text-primary">notifications</span>
          <div className="flex-grow">
            <h4 className="font-medium">{notification.title}</h4>
            <p className="text-sm text-neutral-dark">{notification.message}</p>
            <div className="flex justify-end mt-2 gap-2">
              {notification.actions?.secondary && (
                <button
                  className="px-3 py-1 text-xs text-neutral-dark hover:bg-neutral-lightest rounded"
                  onClick={() => {
                    notification.actions?.secondary?.onClick();
                    dismissNotification(notification.id);
                  }}
                >
                  {notification.actions.secondary.label}
                </button>
              )}
              {notification.actions?.primary && (
                <button
                  className="px-3 py-1 text-xs bg-primary text-white rounded hover:bg-primary-dark"
                  onClick={() => {
                    notification.actions?.primary?.onClick();
                    handleTakeNow(notification.id);
                  }}
                >
                  {notification.actions.primary.label}
                </button>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
