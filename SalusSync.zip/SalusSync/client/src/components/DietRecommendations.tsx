import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DietRecommendation } from "@/lib/types";

interface DietRecommendationsProps {
  recommendation?: DietRecommendation;
  onGetPersonalized: () => void;
}

export default function DietRecommendations({ recommendation, onGetPersonalized }: DietRecommendationsProps) {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="font-heading text-lg">Diet Recommendations</CardTitle>
      </CardHeader>
      <CardContent className="p-5 space-y-4">
        {recommendation ? (
          <>
            <div className="flex items-start gap-3">
              <div className="bg-secondary bg-opacity-10 text-secondary p-2 rounded-full">
                <span className="material-icons">restaurant</span>
              </div>
              <div>
                <h4 className="font-medium">{recommendation.title}</h4>
                <p className="text-sm text-neutral-dark">{recommendation.description}</p>
              </div>
            </div>

            <div className="divide-y divide-neutral-light">
              {recommendation.foodsToInclude && recommendation.foodsToInclude.length > 0 && (
                <div className="py-3">
                  <h5 className="font-medium mb-2">Foods to Include</h5>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    {recommendation.foodsToInclude.map((food, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <span className="material-icons text-success text-sm">check_circle</span>
                        <span>{food}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {recommendation.foodsToLimit && recommendation.foodsToLimit.length > 0 && (
                <div className="py-3">
                  <h5 className="font-medium mb-2">Foods to Limit</h5>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    {recommendation.foodsToLimit.map((food, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <span className="material-icons text-error text-sm">remove_circle</span>
                        <span>{food}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </>
        ) : (
          <div className="text-center py-6 text-neutral-dark">
            <span className="material-icons text-4xl mb-2">restaurant</span>
            <p>No diet recommendations available yet.</p>
            <p className="text-sm mt-2">Calculate your BMI to get personalized recommendations.</p>
          </div>
        )}
      </CardContent>
      <CardFooter className="border-t border-neutral-light p-4">
        <Button
          variant="ghost"
          className="w-full text-primary text-sm font-medium hover:bg-neutral-lightest"
          onClick={onGetPersonalized}
        >
          Get Personalized Diet Plan
        </Button>
      </CardFooter>
    </Card>
  );
}
