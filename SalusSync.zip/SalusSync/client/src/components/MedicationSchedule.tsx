import { useState } from "react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MedicationWithSchedule } from "@/lib/types";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface MedicationScheduleProps {
  medications: MedicationWithSchedule[];
  onAddMedication: () => void;
}

export default function MedicationSchedule({ medications, onAddMedication }: MedicationScheduleProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const markAsTakenMutation = useMutation({
    mutationFn: async (scheduleId: number) => {
      const response = await apiRequest("POST", "/api/medication-tracking", {
        scheduleId,
        userId: 1, // Demo user ID
        takenAt: new Date().toISOString(),
        status: "taken",
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/medication-schedules/1"] });
      queryClient.invalidateQueries({ queryKey: ["/api/medication-tracking/1"] });
      toast({
        title: "Success",
        description: "Medication marked as taken",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update medication status",
        variant: "destructive",
      });
    },
  });

  const getStatusClass = (medication: MedicationWithSchedule) => {
    if (!medication.tracking) {
      return "bg-primary-light bg-opacity-10 text-primary";
    }
    
    switch (medication.tracking.status) {
      case "taken":
        return "bg-success bg-opacity-10 text-success";
      case "missed":
        return "bg-error bg-opacity-10 text-error";
      default:
        return "bg-primary-light bg-opacity-10 text-primary";
    }
  };

  const getStatusText = (medication: MedicationWithSchedule) => {
    if (!medication.tracking) {
      return (
        <p className="text-sm text-neutral-dark flex items-center gap-1">
          <span className="material-icons text-sm">schedule</span>
          {medication.schedule?.time} {medication.schedule?.withFood ? "with food" : ""}
        </p>
      );
    }
    
    switch (medication.tracking.status) {
      case "taken":
        return (
          <p className="text-sm text-success flex items-center gap-1">
            <span className="material-icons text-sm">check_circle</span>
            Taken at {new Date(medication.tracking.takenAt).toLocaleTimeString()}
          </p>
        );
      case "missed":
        return (
          <p className="text-sm text-error flex items-center gap-1">
            <span className="material-icons text-sm">schedule</span>
            Missed at {medication.schedule?.time}
          </p>
        );
      default:
        return (
          <p className="text-sm text-neutral-dark flex items-center gap-1">
            <span className="material-icons text-sm">schedule</span>
            {medication.schedule?.time} {medication.schedule?.withFood ? "with food" : ""}
          </p>
        );
    }
  };

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="font-heading text-lg">Today's Medication Schedule</CardTitle>
          <Button variant="ghost" size="sm" onClick={onAddMedication} className="text-primary hover:text-primary-dark">
            <span className="material-icons text-sm mr-1">add</span>
            Add Medication
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="divide-y divide-neutral-light">
          {medications.length === 0 ? (
            <div className="p-5 text-center text-neutral-dark">
              No medications scheduled for today
            </div>
          ) : (
            medications.map((med) => (
              <div key={med.id} className="p-5 flex items-center gap-4">
                <div className={`${getStatusClass(med)} p-3 rounded-full`}>
                  <span className="material-icons">medication</span>
                </div>
                <div className="flex-grow">
                  <div className="flex justify-between">
                    <h4 className="font-medium">{med.name}</h4>
                    <span className="text-neutral-dark text-sm">
                      {med.dosage} · {med.quantity} pill{med.quantity !== 1 ? "s" : ""}
                    </span>
                  </div>
                  {getStatusText(med)}
                </div>
                {!med.tracking && (
                  <button
                    className="p-2 rounded hover:bg-neutral-lightest transition-all"
                    onClick={() => med.schedule && markAsTakenMutation.mutate(med.schedule.id)}
                    disabled={markAsTakenMutation.isPending}
                  >
                    <span className="material-icons text-neutral-dark">check_circle_outline</span>
                  </button>
                )}
              </div>
            ))
          )}
        </div>
      </CardContent>
      <CardFooter className="border-t border-neutral-light p-4">
        <Button variant="ghost" className="w-full text-primary text-sm font-medium hover:bg-neutral-lightest">
          View All Medications
        </Button>
      </CardFooter>
    </Card>
  );
}
