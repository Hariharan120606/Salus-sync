import { useState } from "react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { HealthMetric, BMICalculationResult } from "@/lib/types";
import BMICalculatorModal from "./BMICalculatorModal";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface BMITrackerProps {
  healthMetrics: HealthMetric[];
  currentBMI?: number;
}

export default function BMITracker({ healthMetrics, currentBMI = 0 }: BMITrackerProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const queryClient = useQueryClient();

  const saveHealthMetricMutation = useMutation({
    mutationFn: async (result: BMICalculationResult) => {
      const response = await apiRequest("POST", "/api/health-metrics", {
        userId: 1, // Demo user
        weight: Math.round(result.weight.value * 10), // Convert to integer (kg * 10)
        height: Math.round(result.height.value), // In cm
        bmi: Math.round(result.bmi * 10), // BMI * 10
        measuredAt: new Date().toISOString(),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/health-metrics/1"] });
    },
  });

  const handleBMICalculated = (result: BMICalculationResult) => {
    // Save the new BMI measurement
    saveHealthMetricMutation.mutate(result);
  };

  // Prepare chart data
  const chartData = healthMetrics.slice().reverse().map((metric) => ({
    date: new Date(metric.measuredAt).toLocaleDateString(),
    bmi: metric.bmi / 10, // Convert from stored integer to decimal
  }));

  return (
    <>
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="font-heading text-lg">BMI Tracking</CardTitle>
        </CardHeader>
        <CardContent>
          {/* BMI Chart */}
          <div className="h-64 mb-4 bg-neutral-lightest rounded">
            {chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={chartData}
                  margin={{
                    top: 10,
                    right: 10,
                    left: 0,
                    bottom: 0,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis domain={[15, 35]} />
                  <Tooltip />
                  <Area
                    type="monotone"
                    dataKey="bmi"
                    stroke="hsl(var(--primary))"
                    fill="hsl(var(--primary))"
                    fillOpacity={0.1}
                  />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-neutral-dark">
                <div className="text-center">
                  <span className="material-icons text-4xl mb-2">show_chart</span>
                  <p>No BMI data available. Add your first measurement.</p>
                </div>
              </div>
            )}
          </div>

          {/* BMI Categories */}
          <div className="grid grid-cols-4 gap-2 text-center text-xs">
            <div className="p-2 rounded bg-info bg-opacity-10">
              <p className="font-medium mb-1">Underweight</p>
              <p>Below 18.5</p>
            </div>
            <div className="p-2 rounded bg-success bg-opacity-10">
              <p className="font-medium mb-1">Normal</p>
              <p>18.5-24.9</p>
            </div>
            <div className="p-2 rounded bg-warning bg-opacity-10">
              <p className="font-medium mb-1">Overweight</p>
              <p>25-29.9</p>
            </div>
            <div className="p-2 rounded bg-error bg-opacity-10">
              <p className="font-medium mb-1">Obese</p>
              <p>30 & Above</p>
            </div>
          </div>
        </CardContent>
        <CardFooter className="border-t border-neutral-light p-4">
          <Button
            variant="ghost"
            className="w-full text-primary text-sm font-medium hover:bg-neutral-lightest"
            onClick={() => setIsModalOpen(true)}
          >
            Calculate New BMI
          </Button>
        </CardFooter>
      </Card>

      <BMICalculatorModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onCalculated={handleBMICalculated}
      />
    </>
  );
}
