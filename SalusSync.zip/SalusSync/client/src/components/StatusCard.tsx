import { StatusCardProps } from "@/lib/types";

export default function StatusCard({ title, value, icon, trend }: StatusCardProps) {
  const getTrendColor = (color: string) => {
    switch (color) {
      case "success":
        return "text-secondary";
      case "error":
        return "text-error";
      case "warning":
        return "text-warning";
      case "info":
        return "text-info";
      default:
        return "text-neutral-dark";
    }
  };

  const getTrendIcon = (direction: string) => {
    switch (direction) {
      case "up":
        return "trending_up";
      case "down":
        return "trending_down";
      default:
        return "trending_flat";
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-card p-5">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-neutral-dark text-sm font-medium mb-1">{title}</h3>
          <p className="text-2xl font-semibold">{value}</p>
          {trend && (
            <p className={`text-sm ${getTrendColor(trend.color)} flex items-center`}>
              <span className="material-icons text-sm mr-1">
                {getTrendIcon(trend.direction)}
              </span>
              {trend.text}
            </p>
          )}
        </div>
        <span className="material-icons text-3xl text-primary-light">{icon}</span>
      </div>
    </div>
  );
}
