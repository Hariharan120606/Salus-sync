import { useAuth } from "@/App";

export default function Header() {
  const { user } = useAuth();

  return (
    <header className="bg-primary text-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <span className="material-icons text-2xl">health_and_safety</span>
          <h1 className="text-xl font-heading font-semibold">MediHealth</h1>
        </div>
        <div className="flex items-center gap-4">
          <button className="p-2 rounded-full hover:bg-primary-dark transition-all">
            <span className="material-icons">notifications</span>
          </button>
          <button className="p-2 rounded-full hover:bg-primary-dark transition-all">
            <span className="material-icons">account_circle</span>
          </button>
        </div>
      </div>
    </header>
  );
}
