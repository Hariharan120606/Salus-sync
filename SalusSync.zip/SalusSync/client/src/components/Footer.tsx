export default function Footer() {
  return (
    <footer className="bg-white border-t border-neutral-light py-4">
      <div className="container mx-auto px-4 md:flex justify-between items-center text-sm text-neutral-dark">
        <p>© 2023 MediHealth. All rights reserved.</p>
        <div className="flex gap-4 mt-2 md:mt-0">
          <a href="#" className="hover:text-primary transition-all">
            Privacy Policy
          </a>
          <a href="#" className="hover:text-primary transition-all">
            Terms of Service
          </a>
          <a href="#" className="hover:text-primary transition-all">
            Contact Support
          </a>
        </div>
      </div>
    </footer>
  );
}
