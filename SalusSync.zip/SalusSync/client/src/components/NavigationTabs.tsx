import { Link, useLocation } from "wouter";

export default function NavigationTabs() {
  const [location] = useLocation();

  return (
    <div className="bg-white shadow-sm">
      <div className="container mx-auto">
        <nav className="flex text-sm font-medium overflow-x-auto">
          <Link href="/">
            <a
              className={`px-6 py-4 border-b-2 ${
                location === "/"
                  ? "border-primary text-primary"
                  : "border-transparent hover:text-primary"
              } transition-all flex items-center gap-1 whitespace-nowrap`}
            >
              <span className="material-icons text-sm">dashboard</span>
              Dashboard
            </a>
          </Link>
          <Link href="/medications">
            <a
              className={`px-6 py-4 border-b-2 ${
                location === "/medications"
                  ? "border-primary text-primary"
                  : "border-transparent hover:text-primary"
              } transition-all flex items-center gap-1 whitespace-nowrap`}
            >
              <span className="material-icons text-sm">medication</span>
              Medications
            </a>
          </Link>
          <Link href="/health-metrics">
            <a
              className={`px-6 py-4 border-b-2 ${
                location === "/health-metrics"
                  ? "border-primary text-primary"
                  : "border-transparent hover:text-primary"
              } transition-all flex items-center gap-1 whitespace-nowrap`}
            >
              <span className="material-icons text-sm">monitor_weight</span>
              Health Metrics
            </a>
          </Link>
          <Link href="/calendar">
            <a
              className={`px-6 py-4 border-b-2 ${
                location === "/calendar"
                  ? "border-primary text-primary"
                  : "border-transparent hover:text-primary"
              } transition-all flex items-center gap-1 whitespace-nowrap`}
            >
              <span className="material-icons text-sm">calendar_today</span>
              Calendar
            </a>
          </Link>
          <Link href="/settings">
            <a
              className={`px-6 py-4 border-b-2 ${
                location === "/settings"
                  ? "border-primary text-primary"
                  : "border-transparent hover:text-primary"
              } transition-all flex items-center gap-1 whitespace-nowrap`}
            >
              <span className="material-icons text-sm">settings</span>
              Settings
            </a>
          </Link>
        </nav>
      </div>
    </div>
  );
}
