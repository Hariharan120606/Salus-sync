import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { BMICalculationResult } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

interface BMICalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCalculated: (result: BMICalculationResult) => void;
}

export default function BMICalculatorModal({ isOpen, onClose, onCalculated }: BMICalculatorModalProps) {
  const [height, setHeight] = useState<string>("");
  const [weight, setWeight] = useState<string>("");
  const [heightUnit, setHeightUnit] = useState<"cm" | "ft">("cm");
  const [weightUnit, setWeightUnit] = useState<"kg" | "lb">("kg");
  const { toast } = useToast();

  const calculateBMIMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/calculate-bmi", {
        height: parseFloat(height),
        weight: parseFloat(weight),
        heightUnit,
        weightUnit,
      });
      return response.json();
    },
    onSuccess: (data: BMICalculationResult) => {
      onCalculated(data);
      toast({
        title: "BMI Calculated",
        description: `Your BMI is ${data.bmi} (${data.category})`,
      });
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to calculate BMI. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!height || !weight) {
      toast({
        title: "Missing Fields",
        description: "Please enter both height and weight",
        variant: "destructive",
      });
      return;
    }
    calculateBMIMutation.mutate();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-heading font-semibold">BMI Calculator</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="space-y-4 py-2">
            <div>
              <Label className="block text-sm font-medium text-neutral-dark mb-1">Height</Label>
              <div className="flex gap-3">
                <div className="flex-grow">
                  <Input
                    type="number"
                    placeholder="Height"
                    value={height}
                    onChange={(e) => setHeight(e.target.value)}
                    required
                  />
                </div>
                <div className="w-24">
                  <Select
                    value={heightUnit}
                    onValueChange={(value) => setHeightUnit(value as "cm" | "ft")}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Unit" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cm">cm</SelectItem>
                      <SelectItem value="ft">ft</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            <div>
              <Label className="block text-sm font-medium text-neutral-dark mb-1">Weight</Label>
              <div className="flex gap-3">
                <div className="flex-grow">
                  <Input
                    type="number"
                    placeholder="Weight"
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    required
                  />
                </div>
                <div className="w-24">
                  <Select
                    value={weightUnit}
                    onValueChange={(value) => setWeightUnit(value as "kg" | "lb")}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Unit" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="kg">kg</SelectItem>
                      <SelectItem value="lb">lb</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </div>

          <DialogFooter className="mt-4">
            <Button type="submit" disabled={calculateBMIMutation.isPending}>
              {calculateBMIMutation.isPending ? "Calculating..." : "Calculate BMI"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
