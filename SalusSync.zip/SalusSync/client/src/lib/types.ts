// Types used in the frontend

export interface User {
  id: number;
  username: string;
  fullName: string;
  email: string;
}

export interface Medication {
  id: number;
  userId: number;
  name: string;
  dosage: string;
  quantity: number;
  instructions?: string;
  createdAt: string;
}

export interface MedicationSchedule {
  id: number;
  medicationId: number;
  userId: number;
  time: string;
  days: string[];
  withFood: boolean;
  createdAt: string;
}

export interface MedicationTracking {
  id: number;
  scheduleId: number;
  userId: number;
  takenAt: string;
  status: 'taken' | 'missed' | 'skipped';
  createdAt: string;
}

export interface HealthMetric {
  id: number;
  userId: number;
  weight: number; // in kg * 10
  height: number; // in cm
  bmi: number; // BMI * 10
  steps?: number;
  measuredAt: string;
  createdAt: string;
}

export interface DietRecommendation {
  id: number;
  userId: number;
  title: string;
  description: string;
  foodsToInclude?: string[];
  foodsToLimit?: string[];
  createdAt: string;
}

export interface MedicationWithSchedule extends Medication {
  schedule?: MedicationSchedule;
  tracking?: MedicationTracking;
}

export interface BMICalculationResult {
  bmi: number;
  category: string;
  height: {
    value: number;
    unit: string;
  };
  weight: {
    value: number;
    unit: string;
  };
}

export interface BMIRecommendationResult {
  plan_title: string;
  description: string;
  foods_to_include: string[];
  foods_to_limit: string[];
}

export interface StatusCardProps {
  title: string;
  value: string | number;
  icon: string;
  trend?: {
    direction: 'up' | 'down' | 'neutral';
    text: string;
    color: 'success' | 'error' | 'warning' | 'info';
  };
}

export interface NotificationProps {
  id: string;
  title: string;
  message: string;
  type: 'medication' | 'appointment' | 'health' | 'system';
  actions?: {
    primary?: {
      label: string;
      onClick: () => void;
    };
    secondary?: {
      label: string;
      onClick: () => void;
    };
  };
}
