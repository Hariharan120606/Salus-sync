import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/App";
import { useToast } from "@/hooks/use-toast";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Medication } from "@/lib/types";

const medicationFormSchema = z.object({
  name: z.string().min(1, "Medication name is required"),
  dosage: z.string().min(1, "Dosage is required"),
  quantity: z.coerce.number().min(1, "Quantity must be at least 1"),
  instructions: z.string().optional(),
});

type MedicationFormValues = z.infer<typeof medicationFormSchema>;

export default function Medications() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const userId = user?.id || 1;
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedMedication, setSelectedMedication] = useState<Medication | null>(null);

  // Fetch medications
  const { data: medications = [], isLoading } = useQuery<Medication[]>({
    queryKey: [`/api/medications/${userId}`],
  });

  const form = useForm<MedicationFormValues>({
    resolver: zodResolver(medicationFormSchema),
    defaultValues: {
      name: "",
      dosage: "",
      quantity: 1,
      instructions: "",
    },
  });

  // Add medication mutation
  const addMedicationMutation = useMutation({
    mutationFn: async (data: MedicationFormValues) => {
      const response = await apiRequest("POST", "/api/medications", {
        ...data,
        userId,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/medications/${userId}`] });
      setIsAddModalOpen(false);
      form.reset();
      toast({
        title: "Success",
        description: "Medication added successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add medication",
        variant: "destructive",
      });
    },
  });

  // Delete medication mutation
  const deleteMedicationMutation = useMutation({
    mutationFn: async (medicationId: number) => {
      const response = await apiRequest("DELETE", `/api/medications/${medicationId}`, undefined);
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/medications/${userId}`] });
      setSelectedMedication(null);
      toast({
        title: "Success",
        description: "Medication deleted successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete medication",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: MedicationFormValues) => {
    addMedicationMutation.mutate(data);
  };

  const handleDeleteMedication = (medication: Medication) => {
    setSelectedMedication(medication);
  };

  const confirmDelete = () => {
    if (selectedMedication) {
      deleteMedicationMutation.mutate(selectedMedication.id);
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-heading font-semibold mb-1">Medications</h2>
          <p className="text-neutral-dark">Manage your medications and schedules</p>
        </div>
        <Button onClick={() => setIsAddModalOpen(true)}>
          <span className="material-icons mr-2">add</span>
          Add Medication
        </Button>
      </div>

      {isLoading ? (
        <div className="text-center py-8">Loading medications...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {medications.length === 0 ? (
            <div className="col-span-full text-center py-8 bg-white rounded-lg shadow-card">
              <span className="material-icons text-4xl text-neutral mb-2">medication</span>
              <h3 className="text-lg font-medium mb-2">No medications found</h3>
              <p className="text-neutral-dark mb-4">
                Add your first medication to get started.
              </p>
              <Button onClick={() => setIsAddModalOpen(true)}>
                Add Medication
              </Button>
            </div>
          ) : (
            medications.map((medication) => (
              <Card key={medication.id}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between">
                    <div>
                      <CardTitle>{medication.name}</CardTitle>
                      <CardDescription>
                        {medication.dosage} · {medication.quantity} pill
                        {medication.quantity !== 1 ? "s" : ""}
                      </CardDescription>
                    </div>
                    <div className="bg-primary-light bg-opacity-10 text-primary h-10 w-10 flex items-center justify-center rounded-full">
                      <span className="material-icons">medication</span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {medication.instructions && (
                    <p className="text-sm text-neutral-dark">
                      {medication.instructions}
                    </p>
                  )}
                </CardContent>
                <CardFooter className="flex justify-between border-t border-neutral-light pt-4">
                  <Button variant="outline" size="sm">
                    <span className="material-icons text-sm mr-1">edit</span>
                    Edit
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-error"
                    onClick={() => handleDeleteMedication(medication)}
                  >
                    <span className="material-icons text-sm mr-1">delete</span>
                    Delete
                  </Button>
                </CardFooter>
              </Card>
            ))
          )}
        </div>
      )}

      {/* Add Medication Modal */}
      <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Medication</DialogTitle>
            <DialogDescription>
              Enter the details of your medication below.
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Medication Name</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Atorvastatin" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="dosage"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Dosage</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., 10mg" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="quantity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Quantity (pills per dose)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min="1"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="instructions"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Instructions (Optional)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="e.g., Take with food"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button
                  type="submit"
                  disabled={addMedicationMutation.isPending}
                >
                  {addMedicationMutation.isPending
                    ? "Adding..."
                    : "Add Medication"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Modal */}
      <Dialog
        open={!!selectedMedication}
        onOpenChange={(open) => !open && setSelectedMedication(null)}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete {selectedMedication?.name}? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setSelectedMedication(null)}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={confirmDelete}
              disabled={deleteMedicationMutation.isPending}
            >
              {deleteMedicationMutation.isPending
                ? "Deleting..."
                : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
