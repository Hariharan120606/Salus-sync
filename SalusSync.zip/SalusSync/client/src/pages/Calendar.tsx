import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/App";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { MedicationWithSchedule } from "@/lib/types";
import { format, isSameDay } from "date-fns";

export default function Calendar() {
  const { user } = useAuth();
  const userId = user?.id || 1;
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());

  // Fetch medications and schedules
  const { data: medications = [] } = useQuery<MedicationWithSchedule[]>({
    queryKey: [`/api/medications/${userId}`],
  });

  // Fetch medication schedules
  const { data: schedules = [] } = useQuery({
    queryKey: [`/api/medication-schedules/${userId}`],
  });

  // Fetch medication tracking
  const { data: trackings = [] } = useQuery({
    queryKey: [`/api/medication-tracking/${userId}`],
  });

  // Merge medications with their schedules
  const medicationsWithSchedules: MedicationWithSchedule[] = medications.map((med) => {
    const schedule = schedules.find((s) => s.medicationId === med.id);
    // Find the latest tracking for this schedule
    const tracking = schedule
      ? trackings
          .filter((t) => t.scheduleId === schedule.id)
          .sort(
            (a, b) =>
              new Date(b.takenAt).getTime() - new Date(a.takenAt).getTime()
          )[0]
      : undefined;

    return {
      ...med,
      schedule,
      tracking,
    };
  });

  // Filter medications for the selected date
  const getMedicationsForDate = (date: Date) => {
    const dayOfWeek = format(date, "EEEE").toLowerCase();
    
    return medicationsWithSchedules.filter((med) => {
      if (!med.schedule) return false;
      
      // Check if this day is in the schedule
      return med.schedule.days.includes(dayOfWeek);
    });
  };

  const selectedDateMedications = selectedDate
    ? getMedicationsForDate(selectedDate)
    : [];
  
  // Get tracking status for a medication on the selected date
  const getTrackingStatus = (medication: MedicationWithSchedule) => {
    if (!medication.schedule || !selectedDate) return "pending";
    
    const trackingForDate = trackings.find(
      (t) =>
        t.scheduleId === medication.schedule!.id &&
        isSameDay(new Date(t.takenAt), selectedDate)
    );
    
    return trackingForDate?.status || "pending";
  };

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-2xl font-heading font-semibold mb-1">Medication Calendar</h2>
        <p className="text-neutral-dark">View your scheduled medications by date</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Select Date</CardTitle>
          </CardHeader>
          <CardContent>
            <CalendarComponent
              mode="single"
              selected={selectedDate}
              onSelect={setSelectedDate}
              className="border rounded-md p-3"
            />
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>
              {selectedDate
                ? `Medications for ${format(selectedDate, "MMMM d, yyyy")}`
                : "Select a date to view medications"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {selectedDateMedications.length === 0 ? (
              <div className="text-center py-8 text-neutral-dark">
                <span className="material-icons text-4xl mb-2">event_busy</span>
                <p>No medications scheduled for this date.</p>
              </div>
            ) : (
              <div className="divide-y divide-neutral-light">
                {selectedDateMedications.map((med) => (
                  <div key={med.id} className="py-4 flex items-center gap-4">
                    <div
                      className={`p-3 rounded-full ${
                        getTrackingStatus(med) === "taken"
                          ? "bg-success bg-opacity-10 text-success"
                          : getTrackingStatus(med) === "missed"
                          ? "bg-error bg-opacity-10 text-error"
                          : "bg-primary-light bg-opacity-10 text-primary"
                      }`}
                    >
                      <span className="material-icons">medication</span>
                    </div>
                    <div className="flex-grow">
                      <div className="flex justify-between">
                        <h4 className="font-medium">{med.name}</h4>
                        <span className="text-neutral-dark text-sm">
                          {med.dosage} · {med.quantity} pill
                          {med.quantity !== 1 ? "s" : ""}
                        </span>
                      </div>
                      <p className="text-sm text-neutral-dark flex items-center gap-1">
                        <span className="material-icons text-sm">schedule</span>
                        {med.schedule?.time} {med.schedule?.withFood ? "with food" : ""}
                      </p>
                    </div>
                    <div
                      className={`px-2 py-1 rounded text-xs ${
                        getTrackingStatus(med) === "taken"
                          ? "bg-success bg-opacity-10 text-success"
                          : getTrackingStatus(med) === "missed"
                          ? "bg-error bg-opacity-10 text-error"
                          : "bg-neutral-light text-neutral-dark"
                      }`}
                    >
                      {getTrackingStatus(med) === "taken"
                        ? "Taken"
                        : getTrackingStatus(med) === "missed"
                        ? "Missed"
                        : "Pending"}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
