import { useState } from "react";
import { useAuth } from "@/App";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";

export default function Settings() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [reminderInterval, setReminderInterval] = useState(15);

  const handleSaveUserProfile = () => {
    toast({
      title: "Profile Saved",
      description: "Your profile information has been updated.",
    });
  };

  const handleSaveNotifications = () => {
    toast({
      title: "Notification Settings Saved",
      description: "Your notification preferences have been updated.",
    });
  };

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-2xl font-heading font-semibold mb-1">Settings</h2>
        <p className="text-neutral-dark">Manage your account and application preferences</p>
      </div>

      <div className="space-y-6">
        {/* User Profile */}
        <Card>
          <CardHeader>
            <CardTitle>User Profile</CardTitle>
            <CardDescription>
              Update your personal information
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="fullName">Full Name</Label>
                <Input id="fullName" defaultValue={user?.fullName || ""} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" defaultValue={user?.email || ""} />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input id="username" defaultValue={user?.username || ""} readOnly />
              <p className="text-xs text-neutral-dark">Username cannot be changed</p>
            </div>
          </CardContent>
          <CardFooter>
            <Button onClick={handleSaveUserProfile}>Save Profile</Button>
          </CardFooter>
        </Card>

        {/* Notification Settings */}
        <Card>
          <CardHeader>
            <CardTitle>Notification Settings</CardTitle>
            <CardDescription>
              Configure how you receive medication reminders
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium">Enable Notifications</h3>
                <p className="text-sm text-neutral-dark">
                  Receive push notifications for medication reminders
                </p>
              </div>
              <Switch
                checked={notificationsEnabled}
                onCheckedChange={setNotificationsEnabled}
              />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium">Email Notifications</h3>
                <p className="text-sm text-neutral-dark">
                  Receive email reminders for missed medications
                </p>
              </div>
              <Switch
                checked={emailNotifications}
                onCheckedChange={setEmailNotifications}
                disabled={!notificationsEnabled}
              />
            </div>
            <Separator />
            <div className="space-y-2">
              <Label htmlFor="reminderInterval">Reminder Interval (minutes)</Label>
              <Input
                id="reminderInterval"
                type="number"
                min="5"
                max="60"
                value={reminderInterval}
                onChange={(e) => setReminderInterval(parseInt(e.target.value) || 15)}
                disabled={!notificationsEnabled}
              />
              <p className="text-xs text-neutral-dark">
                How many minutes before the scheduled time to send a reminder
              </p>
            </div>
          </CardContent>
          <CardFooter>
            <Button onClick={handleSaveNotifications} disabled={!notificationsEnabled}>
              Save Notification Settings
            </Button>
          </CardFooter>
        </Card>

        {/* App Information */}
        <Card>
          <CardHeader>
            <CardTitle>About MediHealth</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div>
              <h3 className="font-medium">Version</h3>
              <p className="text-sm text-neutral-dark">1.0.0</p>
            </div>
            <div>
              <h3 className="font-medium">Developer</h3>
              <p className="text-sm text-neutral-dark">MediHealth Team</p>
            </div>
            <div>
              <h3 className="font-medium">Contact Support</h3>
              <p className="text-sm text-neutral-dark">support@medihealth.example.com</p>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline">Privacy Policy</Button>
            <Button variant="outline">Terms of Service</Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}
