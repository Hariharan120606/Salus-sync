import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/App";
import { useToast } from "@/hooks/use-toast";
import StatusCard from "@/components/StatusCard";
import MedicationSchedule from "@/components/MedicationSchedule";
import BMITracker from "@/components/BMITracker";
import DietRecommendations from "@/components/DietRecommendations";
import {
  MedicationWithSchedule,
  HealthMetric,
  DietRecommendation,
  BMICalculationResult,
  BMIRecommendationResult,
} from "@/lib/types";
import BMICalculatorModal from "@/components/BMICalculatorModal";

export default function Dashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showBMIModal, setShowBMIModal] = useState(false);
  const userId = user?.id || 1;

  // Fetch medications and schedules
  const { data: medications = [] } = useQuery<MedicationWithSchedule[]>({
    queryKey: [`/api/medications/${userId}`],
  });

  // Fetch medication schedules
  const { data: schedules = [] } = useQuery({
    queryKey: [`/api/medication-schedules/${userId}`],
  });

  // Fetch medication tracking
  const { data: trackings = [] } = useQuery({
    queryKey: [`/api/medication-tracking/${userId}`],
  });

  // Fetch health metrics
  const { data: healthMetrics = [] } = useQuery<HealthMetric[]>({
    queryKey: [`/api/health-metrics/${userId}`],
  });

  // Fetch latest diet recommendation
  const { data: dietRecommendation } = useQuery<DietRecommendation>({
    queryKey: [`/api/diet-recommendations/${userId}/latest`],
  });

  // Merge medications with their schedules and tracking data
  const medicationsWithSchedules: MedicationWithSchedule[] = medications.map((med) => {
    const schedule = schedules.find((s) => s.medicationId === med.id);
    // Find the latest tracking for this schedule
    const tracking = schedule
      ? trackings
          .filter((t) => t.scheduleId === schedule.id)
          .sort(
            (a, b) =>
              new Date(b.takenAt).getTime() - new Date(a.takenAt).getTime()
          )[0]
      : undefined;

    return {
      ...med,
      schedule,
      tracking,
    };
  });

  // Filter for today's medications
  const todayMedications = medicationsWithSchedules.filter((med) => {
    if (!med.schedule) return false;
    
    // Check if today is in the schedule days
    const today = new Date().toLocaleDateString('en-US', { weekday: 'long' }).toLowerCase();
    return med.schedule.days.includes(today);
  });

  // Get latest BMI
  const latestHealthMetric = healthMetrics.length > 0
    ? healthMetrics[0]
    : undefined;
  
  const currentBMI = latestHealthMetric
    ? (latestHealthMetric.bmi / 10).toFixed(1)
    : "N/A";

  // Determine health status based on BMI
  const getBMIStatus = (bmi: number) => {
    if (bmi < 18.5) return { text: "Underweight", color: "info" as const, direction: "down" as const };
    if (bmi < 25) return { text: "Healthy range", color: "success" as const, direction: "neutral" as const };
    if (bmi < 30) return { text: "Overweight", color: "warning" as const, direction: "up" as const };
    return { text: "Obese range", color: "error" as const, direction: "up" as const };
  };

  // Get BMI recommendations mutation
  const getDietRecommendationsMutation = useMutation({
    mutationFn: async (bmi: number) => {
      const response = await apiRequest("POST", "/api/bmi-recommendations", { bmi });
      return response.json() as Promise<BMIRecommendationResult>;
    },
    onSuccess: (data) => {
      // Save the recommendation to the backend
      saveDietRecommendationMutation.mutate({
        userId,
        title: data.plan_title,
        description: data.description,
        foodsToInclude: data.foods_to_include,
        foodsToLimit: data.foods_to_limit,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to get diet recommendations",
        variant: "destructive",
      });
    },
  });

  // Save diet recommendation mutation
  const saveDietRecommendationMutation = useMutation({
    mutationFn: async (recommendation: {
      userId: number;
      title: string;
      description: string;
      foodsToInclude: string[];
      foodsToLimit: string[];
    }) => {
      const response = await apiRequest("POST", "/api/diet-recommendations", recommendation);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/diet-recommendations/${userId}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/diet-recommendations/${userId}/latest`] });
      
      toast({
        title: "Success",
        description: "Diet recommendations updated based on your BMI",
      });
    },
  });

  const handleBMICalculated = (result: BMICalculationResult) => {
    // After BMI is calculated, get diet recommendations
    getDietRecommendationsMutation.mutate(result.bmi);
  };

  const handleGetPersonalizedDiet = () => {
    if (latestHealthMetric) {
      // Use the latest BMI to get recommendations
      getDietRecommendationsMutation.mutate(latestHealthMetric.bmi / 10);
    } else {
      // No BMI available, prompt to calculate
      setShowBMIModal(true);
    }
  };

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-2xl font-heading font-semibold mb-1">Dashboard</h2>
        <p className="text-neutral-dark">Welcome back, {user?.fullName || "User"}!</p>
      </div>

      {/* Status Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <StatusCard
          title="Current BMI"
          value={currentBMI}
          icon="monitor_weight"
          trend={
            latestHealthMetric
              ? getBMIStatus(latestHealthMetric.bmi / 10)
              : undefined
          }
        />

        <StatusCard
          title="Medications"
          value={medications.length}
          icon="medication"
          trend={
            todayMedications.length > 0
              ? {
                  direction: "neutral",
                  text: `${todayMedications.length} due today`,
                  color: "warning",
                }
              : undefined
          }
        />

        <StatusCard
          title="Activity"
          value={latestHealthMetric?.steps?.toLocaleString() || "0"}
          icon="directions_walk"
          trend={{
            direction: "down",
            text: "Below target",
            color: "error",
          }}
        />
      </div>

      {/* Medication Schedule */}
      <div className="mb-6">
        <MedicationSchedule
          medications={todayMedications}
          onAddMedication={() => console.log("Add medication")}
        />
      </div>

      {/* Health Metrics and BMI Tracking */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <BMITracker
          healthMetrics={healthMetrics}
          currentBMI={latestHealthMetric ? latestHealthMetric.bmi / 10 : undefined}
        />
        
        <DietRecommendations
          recommendation={dietRecommendation}
          onGetPersonalized={handleGetPersonalizedDiet}
        />
      </div>

      {/* BMI Calculator Modal */}
      <BMICalculatorModal
        isOpen={showBMIModal}
        onClose={() => setShowBMIModal(false)}
        onCalculated={handleBMICalculated}
      />
    </div>
  );
}
