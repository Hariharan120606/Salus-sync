import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/App";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Legend } from "recharts";
import { HealthMetric, BMICalculationResult } from "@/lib/types";
import BMICalculatorModal from "@/components/BMICalculatorModal";
import { format } from "date-fns";

export default function HealthMetrics() {
  const { user } = useAuth();
  const userId = user?.id || 1;
  const [showBMIModal, setShowBMIModal] = useState(false);

  // Fetch health metrics
  const { data: healthMetrics = [] } = useQuery<HealthMetric[]>({
    queryKey: [`/api/health-metrics/${userId}`],
  });

  // Prepare chart data
  const chartData = healthMetrics
    .slice()
    .reverse()
    .map((metric) => ({
      date: format(new Date(metric.measuredAt), "MMM d"),
      bmi: metric.bmi / 10, // Convert from stored integer to decimal
      weight: metric.weight / 10, // Convert from stored integer to decimal
      steps: metric.steps || 0,
    }));

  // Handle BMI calculation result
  const handleBMICalculated = (result: BMICalculationResult) => {
    // This is handled in the BMITracker component
    setShowBMIModal(false);
  };

  // BMI category ranges for the chart
  const getBMIColor = (bmi: number) => {
    if (bmi < 18.5) return "hsl(var(--info))";
    if (bmi < 25) return "hsl(var(--success))";
    if (bmi < 30) return "hsl(var(--warning))";
    return "hsl(var(--error))";
  };

  // Get the latest metric
  const latestMetric = healthMetrics.length > 0 ? healthMetrics[0] : null;

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-heading font-semibold mb-1">Health Metrics</h2>
          <p className="text-neutral-dark">
            Track and monitor your health measurements
          </p>
        </div>
        <Button onClick={() => setShowBMIModal(true)}>
          <span className="material-icons mr-2">add</span>
          Add Measurement
        </Button>
      </div>

      {/* Current Metrics Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Current BMI</CardTitle>
            <CardDescription>
              {latestMetric
                ? format(new Date(latestMetric.measuredAt), "MMM d, yyyy")
                : "No data"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-end gap-2">
              <span className="text-3xl font-bold">
                {latestMetric ? (latestMetric.bmi / 10).toFixed(1) : "N/A"}
              </span>
              {latestMetric && (
                <span
                  className={`text-sm ${
                    getBMIColor(latestMetric.bmi / 10) === "hsl(var(--success))"
                      ? "text-success"
                      : getBMIColor(latestMetric.bmi / 10) === "hsl(var(--warning))"
                      ? "text-warning"
                      : getBMIColor(latestMetric.bmi / 10) === "hsl(var(--error))"
                      ? "text-error"
                      : "text-info"
                  }`}
                >
                  {latestMetric.bmi / 10 < 18.5
                    ? "Underweight"
                    : latestMetric.bmi / 10 < 25
                    ? "Normal weight"
                    : latestMetric.bmi / 10 < 30
                    ? "Overweight"
                    : "Obese"}
                </span>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Current Weight</CardTitle>
            <CardDescription>
              {latestMetric
                ? format(new Date(latestMetric.measuredAt), "MMM d, yyyy")
                : "No data"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <span className="text-3xl font-bold">
              {latestMetric ? (latestMetric.weight / 10).toFixed(1) : "N/A"}
              <span className="text-lg ml-1">kg</span>
            </span>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Current Height</CardTitle>
            <CardDescription>
              {latestMetric
                ? format(new Date(latestMetric.measuredAt), "MMM d, yyyy")
                : "No data"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <span className="text-3xl font-bold">
              {latestMetric ? latestMetric.height : "N/A"}
              <span className="text-lg ml-1">cm</span>
            </span>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Metric Trends</CardTitle>
          <CardDescription>
            Track your progress over time
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="bmi">
            <TabsList className="mb-4">
              <TabsTrigger value="bmi">BMI</TabsTrigger>
              <TabsTrigger value="weight">Weight</TabsTrigger>
              <TabsTrigger value="steps">Steps</TabsTrigger>
            </TabsList>
            <TabsContent value="bmi" className="h-80">
              {chartData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart
                    data={chartData}
                    margin={{
                      top: 10,
                      right: 30,
                      left: 0,
                      bottom: 0,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis domain={[15, 35]} />
                    <Tooltip />
                    <Area
                      type="monotone"
                      dataKey="bmi"
                      stroke="hsl(var(--primary))"
                      fill="hsl(var(--primary))"
                      fillOpacity={0.1}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex items-center justify-center text-neutral-dark">
                  No BMI data available
                </div>
              )}
            </TabsContent>
            <TabsContent value="weight" className="h-80">
              {chartData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart
                    data={chartData}
                    margin={{
                      top: 10,
                      right: 30,
                      left: 0,
                      bottom: 0,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Area
                      type="monotone"
                      dataKey="weight"
                      stroke="hsl(var(--secondary))"
                      fill="hsl(var(--secondary))"
                      fillOpacity={0.1}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex items-center justify-center text-neutral-dark">
                  No weight data available
                </div>
              )}
            </TabsContent>
            <TabsContent value="steps" className="h-80">
              {chartData.some((data) => data.steps > 0) ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={chartData}
                    margin={{
                      top: 10,
                      right: 30,
                      left: 0,
                      bottom: 0,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar
                      dataKey="steps"
                      name="Steps"
                      fill="hsl(var(--accent))"
                    />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex items-center justify-center text-neutral-dark">
                  No steps data available
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* BMI Categories */}
      <Card>
        <CardHeader>
          <CardTitle>BMI Categories</CardTitle>
          <CardDescription>
            Understanding your BMI classification
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-info bg-opacity-10 border-0">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Underweight</CardTitle>
              </CardHeader>
              <CardContent>
                <p>BMI below 18.5</p>
                <p className="text-xs mt-2">
                  May indicate insufficient calorie intake or other health issues.
                </p>
              </CardContent>
            </Card>
            <Card className="bg-success bg-opacity-10 border-0">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Normal Weight</CardTitle>
              </CardHeader>
              <CardContent>
                <p>BMI 18.5 to 24.9</p>
                <p className="text-xs mt-2">
                  Generally indicates a healthy weight relative to height.
                </p>
              </CardContent>
            </Card>
            <Card className="bg-warning bg-opacity-10 border-0">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Overweight</CardTitle>
              </CardHeader>
              <CardContent>
                <p>BMI 25 to 29.9</p>
                <p className="text-xs mt-2">
                  May increase risk for heart disease and other conditions.
                </p>
              </CardContent>
            </Card>
            <Card className="bg-error bg-opacity-10 border-0">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Obese</CardTitle>
              </CardHeader>
              <CardContent>
                <p>BMI 30 or above</p>
                <p className="text-xs mt-2">
                  Higher risk for heart disease, diabetes, and other health issues.
                </p>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>

      {/* BMI Calculator Modal */}
      <BMICalculatorModal
        isOpen={showBMIModal}
        onClose={() => setShowBMIModal(false)}
        onCalculated={handleBMICalculated}
      />
    </div>
  );
}
