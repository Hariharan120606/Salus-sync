from flask import Flask, request, jsonify
from flask_cors import CORS
import os

app = Flask(__name__)
CORS(app)

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({"status": "healthy", "service": "bmi-calculator"}), 200

@app.route('/calculate-bmi', methods=['POST'])
def calculate_bmi():
    try:
        data = request.get_json()
        
        # Validate input
        if not all(key in data for key in ['height', 'weight', 'heightUnit', 'weightUnit']):
            return jsonify({
                "error": "Missing required fields",
                "message": "Height, weight, heightUnit, and weightUnit are required"
            }), 400
        
        height = float(data['height'])
        weight = float(data['weight'])
        height_unit = data['heightUnit']
        weight_unit = data['weightUnit']
        
        # Convert to metric if necessary
        if height_unit == 'ft':
            # Convert feet to cm
            height = height * 30.48
        
        if weight_unit == 'lb':
            # Convert pounds to kg
            weight = weight * 0.453592
        
        # Calculate BMI (weight in kg / height in m^2)
        height_m = height / 100  # Convert cm to m
        bmi = round(weight / (height_m * height_m), 1)
        
        # Determine BMI category
        category = ""
        if bmi < 18.5:
            category = "Underweight"
        elif 18.5 <= bmi < 25:
            category = "Normal weight"
        elif 25 <= bmi < 30:
            category = "Overweight"
        else:
            category = "Obese"
        
        return jsonify({
            "bmi": bmi,
            "category": category,
            "height": {
                "value": height,
                "unit": "cm"
            },
            "weight": {
                "value": weight,
                "unit": "kg"
            }
        }), 200
        
    except Exception as e:
        return jsonify({
            "error": "Calculation failed",
            "message": str(e)
        }), 500

@app.route('/bmi-recommendations', methods=['POST'])
def get_bmi_recommendations():
    try:
        data = request.get_json()
        
        if 'bmi' not in data:
            return jsonify({
                "error": "Missing required fields",
                "message": "BMI value is required"
            }), 400
        
        bmi = float(data['bmi'])
        
        # Provide diet recommendations based on BMI
        foods_to_include = []
        foods_to_limit = []
        
        # Base recommendations for everyone
        foods_to_include = [
            "Lean proteins", 
            "Leafy greens", 
            "Whole grains", 
            "Healthy fats"
        ]
        
        foods_to_limit = [
            "Processed foods", 
            "Added sugars", 
            "High sodium foods", 
            "Refined carbs"
        ]
        
        general_advice = ""
        
        # Tailored advice based on BMI category
        if bmi < 18.5:
            general_advice = "Focus on nutrient-dense foods to gain healthy weight."
            foods_to_include.extend(["Nuts and seeds", "Healthy oils", "Avocados"])
        elif 18.5 <= bmi < 25:
            general_advice = "Maintain a balanced diet to support your healthy weight."
        elif 25 <= bmi < 30:
            general_advice = "Moderate calorie intake and increase physical activity."
            foods_to_limit.extend(["High-calorie beverages", "Large portion sizes"])
        else:
            general_advice = "Focus on calorie control and regular exercise."
            foods_to_limit.extend(["Saturated fats", "High-calorie snacks"])
        
        return jsonify({
            "plan_title": "Balanced Diet Plan",
            "description": general_advice,
            "foods_to_include": foods_to_include,
            "foods_to_limit": foods_to_limit
        }), 200
        
    except Exception as e:
        return jsonify({
            "error": "Failed to generate recommendations",
            "message": str(e)
        }), 500

if __name__ == '__main__':
    port = int(os.environ.get("PORT", 8000))
    app.run(host='0.0.0.0', port=port)
