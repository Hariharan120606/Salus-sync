import { pgTable, text, serial, integer, boolean, timestamp, date, time } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User Table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

// Medication Table
export const medications = pgTable("medications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  dosage: text("dosage").notNull(),
  quantity: integer("quantity").notNull(),
  instructions: text("instructions"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertMedicationSchema = createInsertSchema(medications).omit({
  id: true,
  createdAt: true,
});

// Medication Schedule Table
export const medicationSchedules = pgTable("medication_schedules", {
  id: serial("id").primaryKey(),
  medicationId: integer("medication_id").notNull().references(() => medications.id),
  userId: integer("user_id").notNull().references(() => users.id),
  time: time("time").notNull(),
  days: text("days").array().notNull(), // Array of days of the week
  withFood: boolean("with_food").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertMedicationScheduleSchema = createInsertSchema(medicationSchedules).omit({
  id: true,
  createdAt: true,
});

// Medication Tracking Table (record when medications are taken)
export const medicationTracking = pgTable("medication_tracking", {
  id: serial("id").primaryKey(),
  scheduleId: integer("schedule_id").notNull().references(() => medicationSchedules.id),
  userId: integer("user_id").notNull().references(() => users.id),
  takenAt: timestamp("taken_at").notNull(),
  status: text("status").notNull(), // 'taken', 'missed', 'skipped'
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertMedicationTrackingSchema = createInsertSchema(medicationTracking).omit({
  id: true,
  createdAt: true,
});

// Health Metrics Table
export const healthMetrics = pgTable("health_metrics", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  weight: integer("weight").notNull(), // in kilograms * 10 (store as integer)
  height: integer("height").notNull(), // in centimeters
  bmi: integer("bmi").notNull(), // BMI * 10 (store as integer for precision)
  steps: integer("steps"),
  measuredAt: timestamp("measured_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertHealthMetricsSchema = createInsertSchema(healthMetrics).omit({
  id: true,
  createdAt: true,
});

// Diet Recommendations Table
export const dietRecommendations = pgTable("diet_recommendations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  description: text("description").notNull(),
  foodsToInclude: text("foods_to_include").array(),
  foodsToLimit: text("foods_to_limit").array(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertDietRecommendationsSchema = createInsertSchema(dietRecommendations).omit({
  id: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Medication = typeof medications.$inferSelect;
export type InsertMedication = z.infer<typeof insertMedicationSchema>;

export type MedicationSchedule = typeof medicationSchedules.$inferSelect;
export type InsertMedicationSchedule = z.infer<typeof insertMedicationScheduleSchema>;

export type MedicationTracking = typeof medicationTracking.$inferSelect;
export type InsertMedicationTracking = z.infer<typeof insertMedicationTrackingSchema>;

export type HealthMetric = typeof healthMetrics.$inferSelect;
export type InsertHealthMetric = z.infer<typeof insertHealthMetricsSchema>;

export type DietRecommendation = typeof dietRecommendations.$inferSelect;
export type InsertDietRecommendation = z.infer<typeof insertDietRecommendationsSchema>;
